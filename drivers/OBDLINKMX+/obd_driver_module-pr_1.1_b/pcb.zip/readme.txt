*********************************************************************
   OBD Driver Module, Rev B
   Copyright (C) 2013 OBD Solutions, All Rights Reserved
*********************************************************************


======================================
============== Contents ==============
======================================

The Following Files Accompany This Job:

Gerber RS-274X files:
	coppert.gbr	Top side copper
	copperb.gbr	Bottom side copper
	fab.gbr		Fabrication print
	maskt.gbr	Top side solder mask
	maskb.gbr	Bottom side solder mask
	pastet.gbr	Top side solder paste
	silkt.gbr	Top side silkscreen

Excellon Drill files:
	drill.exl	NC drill file

Other Files:
	readme.txt	This file


======================================
=============== Notes ================
======================================

 - The gerber files provided are viewed from the top side.
 - Hole sizes are the finished hole sizes.
 - Excellon Format: 1.4 Leading, Absolute, Imperial
 - The board should be routed to the outline in fab.gbr


======================================
========= Revision History ===========
======================================

Rev A - David D (2012.10.27)
	Initial release

Rev B - Jason (2013.09.17)
	Connected all VOUT pins of regulator,reversed ISO comparator inputs
